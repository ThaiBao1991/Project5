import tkinter as tk
from tkinter import ttk
import pandas as pd
import datetime
# Biến toàn cục
data_df = None
original_df = None
filters = {}
current_period = None
period=None
tree = None
frame_buttons = None
send_frame = None
label_file = None
entry_file = None
frame_table = None
frame_status_buttons = None
btn_back = None
month_year_var = None