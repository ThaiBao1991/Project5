# Directory Tree for: C:/Users/12953 bao/Desktop/desktop/work/Project/Python/BasicLearnPython/W3schools/Python Tutorial/ProjectInMBC/SendEmailToCustomer

- SendEmailToCustomer/
    - main.py
    - ult/
        - SendEmail/
            - __init__.py
            - File/
                - Data/
                    - file_data.py
            - Guidle/
                - config.py
                - data.py
                - gui.py
                - state.py
